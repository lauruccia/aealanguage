<x-filament-panels::page>
    {{ $this->form }}
    <div class="mt-6">
        {{ $this->table }}
    </div>
</x-filament-panels::page>
